function ReservationsManagement()
{

}

export default ReservationsManagement;