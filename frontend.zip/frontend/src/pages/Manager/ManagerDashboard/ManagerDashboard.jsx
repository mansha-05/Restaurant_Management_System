import React from "react";

function ManagerDashboard()
{

}

export default ManagerDashboard;