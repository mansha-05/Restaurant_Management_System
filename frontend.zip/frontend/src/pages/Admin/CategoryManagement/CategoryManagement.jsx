import React from "react";
import "./CategoryManagement.css";

function CategoryManagement()
{

}

export default CategoryManagement;
