export const config = {
    server : 'http://localhost:8080'
}